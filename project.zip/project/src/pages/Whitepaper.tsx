import { useEffect } from 'react'

export default function Whitepaper() {
  useEffect(() => {
    const link = document.createElement('a')
    link.href = '/demi_whitepaper.pdf'
    link.download = 'demi_whitepaper.pdf'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    window.location.href = '/' // Redirect home per PRD (stay on current, but for simplicity)
  }, [])

  return <div>Downloading whitepaper...</div>
}