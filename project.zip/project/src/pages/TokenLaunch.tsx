import ExchangeInterface from '@/components/TokenLaunch/ExchangeInterface'
import PriceTier from '@/components/TokenLaunch/PriceTier'
import TransactionDetails from '@/components/TokenLaunch/TransactionDetails'
import PaymentInstructions from '@/components/TokenLaunch/PaymentInstructions'
import { Card, CardContent } from '@/components/ui/card'
import { useState, useEffect } from 'react'
import { getTokenPrice } from '@/lib/api-mock'

export default function TokenLaunch() {
  const [tier, setTier] = useState({ currentPrice: '0.01' })

  useEffect(() => {
    getTokenPrice().then(setTier)
    const interval = setInterval(() => getTokenPrice().then(setTier), 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-4xl font-bold text-center mb-8 text-foreground">$DEMI</h1>
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <ExchangeInterface currentPrice={tier.currentPrice} />
          </CardContent>
        </Card>
        <div className="space-y-6">
          <PriceTier tierEndTime={Date.now() + 300000} /> {/* From mock */}
          <TransactionDetails />
          <PaymentInstructions />
        </div>
      </div>
    </div>
  )
}