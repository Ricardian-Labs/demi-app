import { useEffect, useRef, useState } from 'react'
import Typed from 'typed.js'
import { Volume2, VolumeX } from 'lucide-react'
import { Button } from '@/components/ui/button'

const TEXT = `Welcome to DEMI DEX+

The Future of Decentralized Trading. Our revolutionary decentralized exchange built by ex-Ethereum and ex-Polkadot devs empowers $DEMI holders 
with unprecedented earning potential. Every $DEMI holder automatically earns over 13% APY through our 
innovative staking and liquidity provision mechanisms. Your $DEMI tokens work for you 24/7, generating returns from 
trading fees, liquidity rewards, and our unique profit-sharing model. We are allocating 50%  of our ICO raise Community & Liquidity Pool and 50% to Team & Development Fund. Demi is built on Polygon which aids lightning-fast transactions with minimal fees, ensuring maximum returns for our holders. $DEMI isn't just another token – it's your gateway to sustainable passive income in the DeFi ecosystem.$DEMI will become the world's biggest ICO launch, setting new standards for community-driven finance. Demi Token goes public on Decemeber 2nd.`

export default function DexPlus() {
  const el = useRef<HTMLDivElement>(null)
  const typedRef = useRef<Typed | null>(null)
  const [soundOn, setSoundOn] = useState(false)
  const audioRef = useRef(new Audio('/keyboard-click.mp3')) // Add sound file to public

  useEffect(() => {
    if (el.current && !typedRef.current) {
      typedRef.current = new Typed(el.current, {
        strings: [TEXT],
        typeSpeed: 60,
        backSpeed: 30,
        backDelay: 1000,
        loop: false,
        onStringTyped: () => {}, // End with cursor
        cursorChar: '_',
      })
    }

    return () => {
      typedRef.current?.destroy()
    }
  }, [])

  const toggleSound = () => {
    setSoundOn(!soundOn)
    if (soundOn) {
      audioRef.current.pause()
    } else {
      audioRef.current.loop = true
      audioRef.current.play()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center p-4">
      <div className="text-center max-w-4xl">
        <h1 className="text-4xl font-bold mb-8 text-primary">Dex+</h1>
        <div 
          ref={el} 
          className="text-xl md:text-3xl font-mono whitespace-pre-wrap text-white mb-8"
          style={{ lineHeight: '1.5', minHeight: '400px' }}
        />
        <Button variant="outline" onClick={toggleSound} className="mx-auto">
          {soundOn ? <VolumeX className="h-4 w-4 mr-2" /> : <Volume2 className="h-4 w-4 mr-2" />}
          {soundOn ? 'Sound Off' : 'Sound On'}
        </Button>
      </div>
    </div>
  )
}