/* import { describe, it, expect } from 'vitest'
import { calculateDemiReceive, usdToBigInt, bigIntToUsd } from '@/lib/bn'

describe('BigNumber Helpers', () => {
  it('converts USD to BigInt and back', () => {
    const amount = '10.123456'
    const big = usdToBigInt(amount)
    expect(big).toBe(10123456n)
    expect(bigIntToUsd(big)).toBe('10.123456')
  })

  it('calculates DEMI receive exactly', () => {
    const receive = calculateDemiReceive('10', '0.01')
    expect(receive).toBe('1000.000000000000000000') // With decimals
  })

  it('throws on zero price', () => {
    expect(() => calculateDemiReceive('10', '0')).toThrow('Price cannot be zero')
  })
}) */