import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Copy } from 'lucide-react'

interface InstructionsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function InstructionsModal({ open, onOpenChange }: InstructionsModalProps) {
  const address = '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>How to Send USDC/USDT</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-sm">
          <ol className="list-decimal space-y-2 pl-4">
            <li>
              Copy the DEMI address
              <div className="flex items-center space-x-2 mt-1">
                <code>{address}</code>
                <Button variant="outline" size="sm" onClick={() => navigator.clipboard.writeText(address)}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </li>
            <li>
              Send from your wallet
              <ul className="list-disc pl-4 mt-1 space-y-1">
                <li>Open your crypto wallet</li>
                <li>Select "Send" and choose USDC/USDT</li>
                <li>Paste the address and enter amount</li>
                <li>Confirm transaction</li>
              </ul>
            </li>
          </ol>
          <p>Your DEMI tokens will be allocated after confirmation.</p>
        </div>
      </DialogContent>
    </Dialog>
  )
}