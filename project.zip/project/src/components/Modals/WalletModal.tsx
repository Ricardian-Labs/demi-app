import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { useConnect, useAccount } from 'wagmi'
import { injected } from '@wagmi/connectors'
import { useState } from 'react'
import { ExternalLink } from 'lucide-react'
import { coinbaseWallet as wagmiCoinbaseWallet } from '@wagmi/connectors'
import { walletConnect as wagmiWalletConnect } from '@wagmi/connectors'

interface WalletModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function WalletModal({ open, onOpenChange }: WalletModalProps) {
  const { connect } = useConnect()
  const { isConnected } = useAccount()
  const [error, setError] = useState<unknown | string>('')
    void setError;
  const connectors = [
    {
      id: 'metaMask',
      name: 'MetaMask',
      logo: '/icons/metamask.svg',
      installUrl: 'https://metamask.io/download/',
      connect: () => connect({ connector: injected() }),
      isInstalled: !!window.ethereum?.isMetaMask,
    },
    {
      id: 'coinbase',
      name: 'Coinbase Wallet',
      logo: '/icons/coinbase.svg',
      installUrl: 'https://www.coinbase.com/wallet',
      connect: () => connect({ connector: coinbaseWallet({ appName: 'Demi' }) }),
      isInstalled: !!window.ethereum?.isCoinbaseWallet,
    },
    {
      id: 'walletConnect',
      name: 'WalletConnect',
      logo: '/icons/walletconnect.svg',
      installUrl: 'https://walletconnect.com/',
      connect: () => connect({ connector: walletConnect({ projectId: import.meta.env.VITE_WALLET_CONNECT_PROJECT_ID as string }) }),
      isInstalled: true, // Always available via QR
    },
  ]

  if (isConnected) {
    onOpenChange(false)
    return null
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect Wallet</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {connectors.map((wallet) => (
            <Button
              key={wallet.id}
              variant="outline"
              className="w-full justify-start"
              onClick={wallet.connect}
              disabled={!wallet.isInstalled}
            >
              <img src={wallet.logo} alt={wallet.name} className="h-5 w-5 mr-2" />
              {wallet.isInstalled ? wallet.name : `Install ${wallet.name}`}
              {!wallet.isInstalled && <ExternalLink className="ml-auto h-4 w-4" />}
            </Button>
          ))}
        </div>
        {typeof error === 'string' && error && (
          <p className="text-destructive text-sm mt-4">{error}</p>
        )}
        <div className="text-center text-sm text-muted-foreground mt-4">
          Don't see your wallet? Manually send to <strong className="text-primary">0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7</strong>
        </div>
      </DialogContent>
    </Dialog>
  )
}
function coinbaseWallet(arg0: { appName: string }) {
    return wagmiCoinbaseWallet(arg0)
}
function walletConnect(arg0: { projectId: string }) {
    return wagmiWalletConnect(arg0)
}

