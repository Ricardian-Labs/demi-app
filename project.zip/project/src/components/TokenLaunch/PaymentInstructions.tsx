import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Copy} from 'lucide-react'
import { Button } from '@/components/ui/button'
import InstructionsModal from '@/components/Modals/InstructionsModal'
import { useState } from 'react'

const DEMI_ADDRESS = '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb7'

export default function PaymentInstructions() {
  const [showModal, setShowModal] = useState(false)
  const [copied, setCopied] = useState(false)

  const copyAddress = () => {
    navigator.clipboard.writeText(DEMI_ADDRESS)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment Instructions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
          <span>DEMI Address:</span>
          <code className="bg-muted px-2 py-1 rounded text-sm font-mono">{DEMI_ADDRESS}</code>
          <Button variant="ghost" size="sm" onClick={copyAddress}>
            <Copy className="h-4 w-4" />
            {copied ? 'Copied!' : 'Copy'}
          </Button>
        </div>
        <Button onClick={() => setShowModal(true)} className="w-full">View Steps</Button>
        <p className="text-sm text-muted-foreground">Estimated time: About 1 minute</p>
        <InstructionsModal open={showModal} onOpenChange={setShowModal} />
      </CardContent>
    </Card>
  )
}