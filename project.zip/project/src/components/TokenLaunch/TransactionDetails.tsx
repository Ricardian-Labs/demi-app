import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useAccount } from 'wagmi'
import { getWalletBalance } from '@/lib/api-mock'
import { useState, useEffect } from 'react'
import { DollarSign } from 'lucide-react'

export default function TransactionDetails() {
  const { address } = useAccount()
  const [balance, setBalance] = useState({ usdc: '0', usdt: '0' })

  useEffect(() => {
    if (address) {
      getWalletBalance(address).then((data) => {
        setBalance(data.balances)
      })
    }
  }, [address])

  if (!address) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex justify-between">
          <span>Balance:</span>
          <span className="font-medium">{balance.usdc} USDC</span>
        </div>
        {/* Add USDT similarly */}
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <DollarSign className="h-4 w-4" />
          <span>Max: {balance.usdc}</span>
        </div>
      </CardContent>
    </Card>
  )
}