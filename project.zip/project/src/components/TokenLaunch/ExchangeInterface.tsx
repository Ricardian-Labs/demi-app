import { CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { ArrowLeftRight } from 'lucide-react'
import { useState } from 'react'
import { calculateDemiReceive } from '@/lib/bn'
import { calculatePurchase } from '@/lib/api-mock'
import { z } from 'zod'

const sendSchema = z.object({
  amount: z.string().regex(/^\d+(\.\d{0,6})?$/, 'Max 6 decimals'),
})

interface ExchangeInterfaceProps {
  currentPrice: string
}

export default function ExchangeInterface({ currentPrice }: ExchangeInterfaceProps) {
  const [sendToken, setSendToken] = useState<'USDC' | 'USDT'>('USDC')
  const [sendAmount, setSendAmount] = useState('')
  const [receiveAmount, setReceiveAmount] = useState('')
  const [calcData, setCalcData] = useState({ fee: '0', estimatedTime: '' })

  void sendAmount;

  const handleSendChange = async (value: string) => {
    const validated = sendSchema.safeParse({ amount: value })
    if (!validated.success) return // Zod validation

    setSendAmount(value)
    try {
      const demi = calculateDemiReceive(value, currentPrice)
      setReceiveAmount(demi)
      const calc = await calculatePurchase({ sendAmount: value, sendToken, currentPrice })
      setCalcData(calc)
    } catch (e) {
      console.error(e)
    }
  }

  return (
    <>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Exchange</span>
          <ArrowLeftRight className="h-5 w-5 text-muted-foreground" />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Receive</label>
          <div className="flex items-center space-x-2">
            <img src="/icons/demi-logo.svg" alt="DEMI" className="h-5 w-5" />
            <span>DEMI</span>
            <Input value={receiveAmount} readOnly className="flex-1 bg-muted" />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Send</label>
          <div className="flex items-center space-x-2">
            <img src="/icons/usdc.svg" alt={sendToken} className="h-5 w-5" />
            <Select value={sendToken} onValueChange={(v) => setSendToken(v as 'USDC' | 'USDT')}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USDC">USDC</SelectItem>
                <SelectItem value="USDT">USDT</SelectItem>
              </SelectContent>
            </Select>
            <Input placeholder="0.00" onChange={(e) => handleSendChange(e.target.value)} className="flex-1" />
          </div>
        </div>
        <Button className="w-full bg-gradient-to-r from-primary to-blue-600">Swap</Button> {/* Placeholder */}
        <div className="text-xs text-muted-foreground">
          1 DEMI = ${currentPrice} | Fee: {calcData.fee} {sendToken} | {calcData.estimatedTime}
        </div>
      </CardContent>
    </>
  )
}