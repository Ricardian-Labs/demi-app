import { Progress } from '@/components/ui/progress' // Add via npx shadcn add progress
import { useCountdown } from '@/hooks/useCountdown'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Clock } from 'lucide-react'

interface PriceTierProps {
  tierEndTime: number
}

export default function PriceTier({ tierEndTime }: PriceTierProps) {
  const { timeLeft, isExpired } = useCountdown(tierEndTime)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Price Tier</span>
          <Clock className="h-4 w-4" />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="text-2xl font-bold">$0.01</div>
          <div className="text-sm text-muted-foreground">Current Price</div>
        </div>
        <Progress value={50} className="h-2" /> {/* Mock progress; real = (sold / available) * 100 */}
        <div className="flex justify-between text-sm">
          <span>Next: $0.02</span>
          <span>{timeLeft}</span>
        </div>
        {isExpired && <div className="text-destructive text-sm">Tier expired! Price updated.</div>}
      </CardContent>
    </Card>
  )
}