export default function Footer() {
  return (
    <footer className="bg-background border-t border-border py-4">
      <div className="container mx-auto text-center text-muted-foreground text-sm">
        &copy; 2025 Demi Token Launch. Built on Polygon.
      </div>
    </footer>
  )
}