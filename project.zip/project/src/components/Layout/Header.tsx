import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Wallet } from 'lucide-react'
import { useAccount, useDisconnect } from 'wagmi'
import WalletModal from '@/components/Modals/WalletModal'

import { useState } from 'react'

export default function Header() {
  const { address } = useAccount()
  const { disconnect } = useDisconnect()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const location = useLocation()

  const isTokenLaunch = location.pathname === '/'
  const isDexPlus = location.pathname === '/dex-plus'

  return (
    <header className="bg-background/80 backdrop-blur-sm border-b border-border sticky top-0 z-50 px-4">
      <div className="container mx-auto flex items-center justify-between py-4">
        <Link to="/" className="flex items-center space-x-2">
          <img src="/icons/demi-logo.svg" alt="Demi Logo" className="h-8 w-8" />
          <span className="font-bold text-xl text-primary">demi</span>
        </Link>
        <nav className="flex space-x-6">
          <Link to="/" className={`hover:text-primary transition-colors ${isTokenLaunch ? 'text-primary' : ''}`}>
            Token Launch
          </Link>
          <button onClick={() => window.location.href = '/demi_whitepaper.pdf'} className="hover:text-primary transition-colors">
            Whitepaper
          </button>
          <Link to="/dex-plus" className={`hover:text-primary transition-colors ${isDexPlus ? 'text-primary' : ''}`}>
            Dex+
          </Link>
        </nav>
        <div className="flex items-center space-x-2">
          {address ? (
            <>
              <span className="text-sm">{address.slice(0, 6)}...{address.slice(-4)}</span>
              <Button variant="outline" size="sm" onClick={() => disconnect()}>
                Disconnect
              </Button>
            </>
          ) : (
            <Button onClick={() => setIsModalOpen(true)} className="bg-gradient-to-r from-primary to-blue-600">
              <Wallet className="mr-2 h-4 w-4" /> Connect Wallet
            </Button>
          )}
        </div>
        <WalletModal open={isModalOpen} onOpenChange={setIsModalOpen} />
      </div>
    </header>
  )
}