import { Routes, Route } from 'react-router-dom'
import Layout from '@/components/Layout/Layout' // We'll create this next
import TokenLaunch from '@/pages/TokenLaunch'
import DexPlus from '@/pages/DexPlus'
import Whitepaper from '@/pages/WhitePaper'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout><TokenLaunch /></Layout>} />
      <Route path="/dex-plus" element={<Layout><DexPlus /></Layout>} />
      <Route path="/whitepaper" element={<Whitepaper />} /> {/* No layout for download */}
    </Routes>
  )
}

export default App