import { useState, useEffect } from 'react'

export function useCountdown(endTime: number) {
  const [timeLeft, setTimeLeft] = useState(endTime - Date.now())

  useEffect(() => {
    if (timeLeft <= 0) return

    const interval = setInterval(() => {
      setTimeLeft(endTime - Date.now())
    }, 1000)

    return () => clearInterval(interval)
  }, [endTime, timeLeft])

  const isExpired = timeLeft <= 0
  const formatted = new Date(timeLeft).toISOString().substr(11, 8) // HH:MM:SS

  return { timeLeft: formatted, isExpired }
}